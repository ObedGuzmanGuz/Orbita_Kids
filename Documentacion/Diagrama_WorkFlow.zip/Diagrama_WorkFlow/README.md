# Órbita Kids · Workflow interactivo

Dashboard local para explicar el recorrido propuesto de una actividad matemática, basado en la composición de la referencia `Ejemplo_macaGest.png`.

## Archivos

- `workflow-orbita-kids.html`: dashboard independiente. Abrir directamente en Chrome o Edge; no necesita servidor ni realiza llamadas de red.
- `workflow-orbita-kids.json`: fuente editable del diagrama en formato Archify Workflow v2.
- `assets/workflow-orbita-kids.archify.html`: render HTML generado por Archify desde ese modelo.
- `assets/logos/`: logotipos originales encontrados en el repositorio.
- `assets/icons/orbita-symbols.svg`: símbolos SVG locales de apoyo.
- `capturas/workflow-preview.png`: captura de Archify/Chrome a 2048×1320, con todo el dashboard visible.
- `capturas/workflow-preview-1366x768.png`: captura del dashboard en laptop.
- `build-dashboard.ps1`: generador reproducible del HTML del dashboard a partir del JSON y los logos.

## Uso

1. Abre `workflow-orbita-kids.html` en Chrome o Edge.
2. Selecciona una etapa para ver detalles, entradas, salidas y estado.
3. Usa Reproducir, Pausar, Reiniciar, Anterior, Siguiente y Velocidad para recorrer los paquetes SVG animados. Las opciones de respuesta correcta e incorrecta muestran las dos ramas.
4. Usa Presentar para ampliar el área de trabajo.
5. El botón Archify abre el render del modelo. El JSON puede modificarse con Archify y el dashboard regenerarse con `powershell -ExecutionPolicy Bypass -File .\build-dashboard.ps1`.

## Alcance técnico y fidelidad

La inspección encontró documentación, wireframes e identidad gráfica, pero no una aplicación Flutter/Dart funcional, backend FastAPI, PWA React, endpoints, modelos/esquemas SQL ni despliegue Docker conectado. Las comunicaciones, persistencia, autenticación, progreso y recompensas aparecen como diseño/propuesta, no como operaciones implementadas. No se inventan rutas REST ni nombres de tablas. La suma `8 + 5 = ?` es solo una ilustración.

Keycloak, Redis y Grafana tampoco se encontraron integrados. La simulación es local y no emite solicitudes reales.

## Validación

- El modelo Archify Workflow v2 se validó y se generó con el renderer de Archify antes de congelar la fuente JSON.
- El autorreporte en Chrome ejecutó 29 comprobaciones: selección de diez etapas, rutas SVG, ramas correcta/incorrecta, velocidad, pausa, recorrido completo y reinicio. Resultado: **29/29 PASS**.
- Archify visual-check pasó en sus viewports de 1440×900, 1600×1000, 1920×1080 y 2048×1320, sin desbordamiento horizontal o vertical en el HTML entregado. La composición se revisó visualmente en capturas de 1366×768 y 2048×1320. En 1366×768 hay desplazamiento vertical para el detalle inferior; el flujo central y la secuencia aparecen en la primera vista.
- Se incluye el HTML nativo generado por Archify para inspeccionar el modelo. Su renderer conserva desplazamiento vertical; el dashboard principal presenta la simulación en una interfaz compacta.

Las capturas son evidencia visual local, no una afirmación de integración de servicios. El HTML abre offline y no descarga fuentes ni recursos externos.
